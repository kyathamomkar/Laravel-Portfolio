    function settext() {
        var x = document.getElementById('logintext').textContent;
        x= x.trim();
        document.getElementById('logintext').textContent =x;
        if (x === "LOGIN") {
            document.getElementById('logintext').href = "/login";
        }
        else
        {
            document.getElementById('logintext').href = "/logout";

        }
    }
window.onload = settext;
