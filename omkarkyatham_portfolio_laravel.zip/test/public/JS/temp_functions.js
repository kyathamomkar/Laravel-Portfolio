/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(function() {
  //defining all needed variables
  var $overlay = $('.overlay');
  var $mainPopUp = $('.main-popup')
  var $signIn = $('#sign-in');
  var $register = $('#register');
  var $formSignIn = $('form.sign-in');
  var $formRegister = $('form.register');

  var $firstChild = $('nav ul li:first-child');
  var $secondChild = $('nav ul li:nth-child(2)');
  var $thirdChild = $('nav ul li:nth-child(3)');



  // Get the modal
var $modal = $('#myModal');

// Get the button that opens the modal
var $btn = $('#myBtn');

// Get the <span> element that closes the modal
var $span = $('.close2');


  //defining function to create underline initial state on document load
  function initialState() {
    $('.underline').css({
      "width": $firstChild.width(),
      "left": $firstChild.position().left,
      "top": $firstChild.position().top + $firstChild.outerHeight(true) + 'px'
    });
  }
  initialState(); //() used after calling function to call function immediately on doc load

  //defining function to change underline depending on which li is active
  function changeUnderline(el) {
    $('.underline').css({
      "width": el.width(),
      "left": el.position().left,
      "top": el.position().top + el.outerHeight(true) + 'px'
    });
  } //note: have not called the function...don't want it called immediately

  $firstChild.on('click', function(){
    var el = $firstChild;
    changeUnderline(el); //call the changeUnderline function with el as the perameter within the called function
    $secondChild.removeClass('active');
    $thirdChild.removeClass('active');
    $(this).addClass('active');
  });

  $secondChild.on('click', function(){
    var el = $secondChild;
    changeUnderline(el); //call the changeUnderline function with el as the perameter within the called function
    $firstChild.removeClass('active');
    $thirdChild.removeClass('active');
    $(this).addClass('active');
  });

  $thirdChild.on('click', function(){
    var el = $thirdChild;
    changeUnderline(el); //call the changeUnderline function with el as the perameter within the called function
    $firstChild.removeClass('active');
    $secondChild.removeClass('active');
    $(this).addClass('active');
  });


   $('.login_in_nav').on('click', function(){
    $overlay.addClass('visible');
    $mainPopUp.addClass('visible');
    $signIn.addClass('active');
    $register.removeClass('active');
    $formRegister.removeClass('move-left');
    $formSignIn.removeClass('move-left');
  });

  $('.index_table_row_td').on('click', function(){
    $overlay.addClass('visible');
    $mainPopUp.addClass('visible');
    $signIn.addClass('active');
    $register.removeClass('active');
    $formRegister.removeClass('move-left');
    $formSignIn.removeClass('move-left');
  });
  $overlay.on('click', function(){
    $(this).removeClass('visible');
    $mainPopUp.removeClass('visible');
  });
  $('#popup-close-button a').on('click', function(e){
    e.preventDefault();
    $overlay.removeClass('visible');
    $mainPopUp.removeClass('visible');
  });

  $('#close').on('click', function(e){
    e.preventDefault();
    $overlay.removeClass('visible');
    $mainPopUp.removeClass('visible');
  });

  $signIn.on('click', function(){
       $("#message").html("");
    $signIn.addClass('active');
    $register.removeClass('active');
    $formSignIn.removeClass('move-left');
    $formRegister.removeClass('move-left');
  });

  $register.on('click', function(){
       $("#message").html("");
    $signIn.removeClass('active');
    $register.addClass('active');
    $formSignIn.addClass('move-left');
    $formRegister.addClass('move-left');
  });










   $('#icon2').on('click', function(){
        clickongallery();
  });

  $('#icon1').on('click', function(){
        clickonprojects();
  });

   $('#icon3').on('click', function(){
        clickonphotos();
  });

  $('#blogid').on('click', function(){
        clickonblog();
  });


  //for ajax code login

   $(".getin").click(function(){

        $("#message").html("");
        var username = $("#email").val().trim();
        var password = $("#password").val().trim();

        if( username !== "" && password !== "" ){
            $.ajax({
                url:'/uservalidation',
                type:'post',
                data:{username:username,password:password},
                headers:
                    {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                success:function(response){

                    var msg = "";
                    if(response == 1){
                        window.location = "adminpanel";
                    }
                    else if(response == 2)
                    {
                        window.location = "about";
                    }
                    else{
                        msg = "Invalid username and password!";
                    }
                    $("#message").html(msg);
                }
            });
        }
        else
        {
              $("#message").html("Enter all details");
        }
    });


//for ajax code register

   $(".registration").click(function(){

        $("#message").html("");
        var username = $("#email-register").val().trim();
        var password1 = $("#password-register").val().trim();
         var password2 = $("#password-confirmation").val().trim();


        if( username !== "" && password1 !== "" && password2 !== "" ){
            if(password1==password2)
            {
            $.ajax({
                url:'/userregistration',
                type:'post',
                data:{username:username,password:password1},
                headers:
                    {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                success:function(response){
                    var msg = "";

                    if(response == 2)
                    {
                        window.location = "about";
                    }
                    else{
                        msg = response;
                        $("#message").html(msg);
                    }

                }
            });
        }
        else
        {
             $("#message").html("Passwords are not matching");
        }
        }
        else
        {
            $("#message").html("Enter all details");
        }
    });




  function clickongallery() {
    $('.flex-container').css({
      "display": "none"
    });
     $('#photos').css({
      "display": "none"
    });
    $('#gallery').css({
      "display": ""
    });
     $('#icon2').css({
       "background-color": "#378C3F",
       "color": "#F7F7F7"
    });

    $('#icon1').css({
       "background-color": "#dfdddd",
       "color": "grey"
    });

    $('#icon3').css({
       "background-color": "#dfdddd",
       "color": "grey"
    });

    }

    function clickonprojects() {
    $('#gallery').css({
      "display": "none"
    });
    $('#photos').css({
      "display": "none"
    });
    $('.flex-container').css({
      "display": ""
    });
     $('#icon1').css({
       "background-color": "#378C3F",
       "color": "#F7F7F7"
    });

   $('#icon2').css({
       "background-color": "#dfdddd",
       "color": "grey"
    });
    $('#icon3').css({
       "background-color": "#dfdddd",
       "color": "grey"
    });


    }


    function clickonphotos()
    {
        $('#gallery').css({
      "display": "none"
    });
     $('.flex-container').css({
      "display": "none"
    });
    $('#photos').css({
      "display": ""
    });
     $('#icon3').css({
       "background-color": "#378C3F",
       "color": "#F7F7F7"
    });

   $('#icon1').css({
       "background-color": "#dfdddd",
       "color": "grey"
    });

        $('#icon2').css({
       "background-color": "#dfdddd",
       "color": "grey"
        });
    }


   // When the user clicks the button, open the modal
$('#myBtn').on('click', function()
{
     $modal.css({
           "display": "block"
    });
});


// When the user clicks on <span> (x), close the modal
$span.on('click', function()
{
    $modal.css({
     "display": "none"
    });
});




});


