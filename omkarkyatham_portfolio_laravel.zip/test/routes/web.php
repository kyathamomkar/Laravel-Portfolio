<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view("default");
});

Route::get('/default', function () {
    return view("default");
});

Route::post('/updateuser','Controller@updateuser');

Route::get('/about','Controller@about');
Route::get('/skills','Controller@skills');
Route::get('/portfolio','Controller@portfolio');
Route::get('/experience','Controller@experience');
Route::get('/prices','Controller@prices');
Route::get('/contact','Controller@contact');
Route::get('/login','Controller@login');
Route::get('/logout','Controller@logout');
Route::get('/adminpanel','Controller@adminpanel');


Route::post('/uservalidation','Controller@uservalidation');
Route::post('/userregistration','Controller@userregistration');
Route::post('/updateuser','Controller@updateuser');
Route::post('/updateeducation','Controller@updateeducation');
Route::post('/updateskill','Controller@updateskill');
Route::post('/updateexperience','Controller@updateexperience');
Route::post('/updateprices','Controller@updateprices');
Route::post('/updateprojects','Controller@updateprojects');
