<?php

namespace App\Http\Controllers;
use Faker\Provider\Image;
use Illuminate\Http\File;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use function Sodium\add;
use const http\Client\Curl\Versions\IDN;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function about() {
        $users = DB::select('select * from aboutuser');
        $education = DB::select('select * from studies');
        return view('about',['users'=>$users, 'education'=>$education]);
    }

    public function skills() {
        $skills = DB::select('select * from skill');
        return view('skills',['skills'=>$skills]);
    }

    public function portfolio() {
        $projects = DB::select('select * from portfolio_projects');
        return view('portfolio',['projects'=>$projects]);
    }

    public function experience() {
        $experience = DB::select('select * from workexperience');
        return view('experience',['experience'=>$experience]);
    }
    public function prices() {
        $prices = DB::select('select * from prices');
        return view('prices',['prices'=>$prices]);
    }
    public function contact() {
        $details = DB::select('select * from aboutuser');
        return view('contact',['details'=>$details]);
    }

    public function uservalidation(Request $request)
    {
        $username = $request->input('username') ;
        $password = $request->input('password') ;
        $query = "select id from users where name='".$username."' and password='".$password."'";
        $user = DB::select($query);
        if($user)
        {
            if($username=='wdm')
            {
                $request->session()->put('user', $username);
                return 1;
            }
            else
            {
                $request->session()->put('user', $username);
                return 2;
            }
        }
        else
        {
            return 3;
        }


        exit;
    }

    public function userregistration(Request $request)
{
    $uname = $request->input('username') ;
    $pass = $request->input('password') ;
    $query = "select id from users where name='".$uname."'";
    $user = DB::select($query);
    if($user)
    {
        return "User already exists";
    }
    else
    {
        $insert = "insert into users(name,password) values ('".$uname."', '".$pass."')";
        $newuser = DB::INSERT($insert);
        if($newuser) {
            $request->session()->put('user', $uname);
        return 2; }
        else
            return "Something went wrong";
    }


    exit;
}

    public function login(Request $request)
    {
        $request->session()->forget('user');
        return view('default');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('user');
        return view('default');
    }


    public function adminpanel(Request $request)
    {
        if($request->session()->has('user'))
        {
            $aboutuser = DB::select('select * from aboutuser');
            $education = DB::select('select * from studies');
            $skills = DB::select('select * from skill');
            $projects = DB::select('select * from portfolio_projects');
            $experience = DB::select('select * from workexperience');
            $prices = DB::select('select * from prices');

            return view('adminpanel',['aboutuser'=>$aboutuser, 'education'=>$education, 'skills'=>$skills, 'projects'=>$projects, 'experience'=>$experience, 'prices'=>$prices]);
        }
        else{
            $request->session()->forget('user');
            return view('default');
        }

    }

    public function updateuser(Request $request)
    {
        $age = $request->input('age') ;
        $description = $request->input('description') ;
        $email = $request->input('email') ;
        $phone = $request->input('phone') ;
        $address = $request->input('address') ;
        $languages = $request->input('language') ;
        if($request->session()->has('user'))
        {
            if($age!=""||$description!=""||$email!=""||$phone!=""||$address!=""||$languages!="")
            {
                $set = ['age' => $age,
                    'description' => $description,
                    'phone' => $phone,
                    'languages' => $languages,
                    'address' => $address,
                    'email' => $email];

                DB::table('aboutuser')
                    ->where('id', 1)
                    ->update($set);

               return "Data Updated. Please refresh the page";

            }
            else  return "Incomplete data sent";
        }

        else return view('default');
    }


    public function updateeducation(Request $request)
    {
        $userid = $request->input('userid') ;
        $degree = $request->input('degree') ;
        $department = $request->input('department') ;
        $duration = $request->input('duration') ;
        $school = $request->input('school') ;

        if($request->session()->has('user'))
        {

            if($degree!=""||$department!=""||$duration!=""||$school!="")
            {

                $set = [
                    'degree' => $degree,
                    'department' => $department,
                    'duration' => $duration,
                    'school' => $school];
                if($userid!="") {
                    DB::table('studies')
                        ->where('userid', $userid)
                        ->update($set);

                    return "Data Updated. Please refresh the page";
                }
                else{
                    $insert = "insert into studies(degree,department,duration,school) values ('".$degree."', '".$department."','".$duration."', '".$school."')";
                    $newuser = DB::INSERT($insert);
                    if($newuser) {
                        return "Data Inserted. Please refresh the page";
                    }
                }

            }
            else  return "Incomplete data sent";
        }

        else return view('default');
    }


    public function updateskill(Request $request)
    {
        $userid = $request->input('userid') ;
        $skill = $request->input('skill') ;
        $percentage = $request->input('percentage') ;


        if($request->session()->has('user'))
        {

            if($skill!=""||$percentage!="")
            {

                $set = [
                    'skill' => $skill,
                    'percentage' => $percentage,
                    ];
                if($userid!="") {
                    DB::table('skill')
                        ->where('userid', $userid)
                        ->update($set);

                    return "Data Updated. Please refresh the page";
                }
                else{
                    $insert = "insert into skill(skill,percentage) values ('".$skill."', '".$percentage."')";
                    $newuser = DB::INSERT($insert);
                    if($newuser) {
                        return "Data Inserted. Please refresh the page";
                    }
                }

            }
            else  return "Incomplete data sent";
        }

        else return view('default');
    }



    public function updateexperience(Request $request)
    {
        $companyid = $request->input('companyid') ;
        $durationfrom = $request->input('durationfrom') ;
        $durationto = $request->input('durationto') ;
        $employer = $request->input('employer') ;
        $position = $request->input('position') ;
        $description = $request->input('description');
        $duration =$durationfrom." to ".$durationto;
        if($request->session()->has('user'))
        {

            if($durationfrom!=""||$durationto!=""||$employer!=""||$position!=""||$description!="")
            {

                $set = [
                    'duration' => $durationfrom." to ".$durationto,
                    'employer' => $employer,
                    'position' => $position,
                    'description' => $description
                    ];
                if($companyid!="") {
                    DB::table('workexperience')
                        ->where('companyid', $companyid)
                        ->update($set);

                    return "Data Updated. Please refresh the page";
                }
                else{
                    $insert = "insert into workexperience(duration,employer,position,description) values ('".$duration."', '".$employer."', '".$position."', '".$description."')";
                    $newuser = DB::INSERT($insert);
                    if($newuser) {
                        return "Data Inserted. Please refresh the page";
                    }
                }

            }
            else  return "Incomplete data sent";
        }

        else return view('default');
    }


    public function updateprices(Request $request)
    {
        $userid = $request->input('userid') ;
        $pay = $request->input('pay') ;
        $position = $request->input('position') ;
        $skills = $request->input('skills') ;

        if($request->session()->has('user'))
        {

            if($pay!=""||$position!=""||$skills!="")
            {

                $set = [
                    'pay' => $pay,
                    'position' => $position,
                    'skills' => $skills];
                if($userid!="") {
                    DB::table('prices')
                        ->where('userid', $userid)
                        ->update($set);

                    return "Data Updated. Please refresh the page";
                }
                else{
                    $insert = "insert into prices(pay,position,skills) values ('".$pay."', '".$position."','".$skills."')";
                    $newuser = DB::INSERT($insert);
                    if($newuser) {
                        return "Data Inserted. Please refresh the page";
                    }
                }

            }
            else  return "Incomplete data sent";
        }

        else return view('default');
    }


    public function updateprojects(Request $request)
    {
        $work = $request->input('work') ;
        $id = $request->input('id') ;

        $link = $request->input('link') ;
        if($request->hasFile('file')) {
            $file = $request->file('file');
            $filename = uniqid() . "." . $file->getClientOriginalExtension();
        }


        switch ($work)
        {
            case 0:
                $filepath = $request->file('file')->storeAs('pics', $filename);
                $set = [
                    'imagepath' => $filepath,
                    'link' => $link,
                    'imageType' => $file->getClientOriginalExtension()];
                DB::table('portfolio_projects')
                    ->where('id', $id)
                    ->update($set);
                return "Updated, Please refresh the page";

            case 1:

            $filepath = $request->file('file')->storeAs('pics', $filename);
            DB::table('portfolio_projects')->insert(array(
                    'imagepath'=> $filepath,
                    'link'=>$link,
                    'imageType'=>$file->getClientOriginalExtension()
                )
            );
            return "Inserted, Please refresh the page";
            case 2:

                $delete = "DELETE FROM portfolio_projects WHERE id='".$id."'";
               $deleted = DB::table('portfolio_projects')->where('id', $id)->delete();

                    return "Record deleted, Please refresh the page";

        }




    }
}
