<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <script src="JS/common.js"></script>
	<style>
.flex-container {
  display: flex;
  flex-wrap: wrap;
   box-shadow:  0px 2px 10px #999999;
  justify-content: center;
  max-width: 600px;
}

.flex-container > div  {

  width: 250px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}
</style>
</head>
<body>
<header>
<nav>
<ul class="nav_list">
    <li><a href="" id="logintext">
            <?php if(Session::has('user')): ?>LOGOUT
            <?php else: ?> LOGIN <?php endif; ?></a></li>
	<li><a href="contact">CONTACT</a></li>
	<li><a href="prices">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a href="experience">EXPERIENCE</a></li>
	<li><a href="portfolio">PORTFOLIO</a></li>
	<li><a class="active_nav" href="skills">SKILLS</a></li>
	<li><a href="about">ABOUT</a></li>
	<li><a href="default">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
</ul>

<select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>

    <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">&nbsp;
<header>
<h2 class="professionalskills_heading">Professional Skills</h2>
</header>
&nbsp;



     <div class="flex-container">


<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div>


			<table class="subject_table">
				<tbody>
					<tr>
						<th class="subject_name"><?php echo e($skill-> skill); ?></th>
						<th class="subject_percentage"><?php echo e($skill-> percentage); ?></th>
					</tr>
					<tr>
						<td colspan="2"><progress class="progress_bar" max="100" value="80"></progress></td>
					</tr>
				</tbody>
			</table>

			</div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&nbsp;


		</div>

</section>
</article>
</center>
</body>
</html>
<?php /**PATH C:\Users\kyath\test\resources\views/skills.blade.php ENDPATH**/ ?>