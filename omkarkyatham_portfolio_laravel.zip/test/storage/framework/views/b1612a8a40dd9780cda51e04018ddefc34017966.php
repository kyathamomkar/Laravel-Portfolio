<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
    <script src="JS/common.js"></script>
</head>
<body class="aboutpage">
<header>
<nav>
<ul class="nav_list">
 <li><a href="" id="logintext">
            <?php if(Session::has('user')): ?>LOGOUT
            <?php else: ?> LOGIN <?php endif; ?></a></li>
	<li><a href="contact">CONTACT</a></li>
	<li><a href="prices">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a href="experience">EXPERIENCE</a></li>
	<li><a href="portfolio">PORTFOLIO</a></li>
	<li><a href="skills">SKILLS</a></li>
	<li><a class="active_nav" href="about">ABOUT</a></li>
	<li><a href="default">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
</ul>


<select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>

     <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">
<section class="info_box">
<table class="outer_table">
	<thead>
		<tr>
			<th class="heading_about">About</th>
			<th class="heading_basicinfo">Basic Information</th>
		</tr>
	</thead>
	<tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td class="description">
			<p><br />
                <?php echo e($user->description); ?>

			</p>
			</td>
			<td>
			<table class="inner_table">
				<thead>
					<tr>
						<th class="fifty"></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="bold_td">AGE:</td>
						<td>  <?php echo e($user->age); ?></td>
					</tr>
					<tr>
						<td class="bold_td">EMAIL:</td>
						<td><a href="mailto: <?php echo e($user->email); ?>">  <?php echo e($user->email); ?></a></td>
					</tr>
					<tr>
						<td class="bold_td">PHONE:</td>
						<td>  <?php echo e($user->phone); ?></td>
					</tr>
					<tr>
						<td class="bold_td">ADDRESS:</td>
						<td>  <?php echo e($user->address); ?></td>
					</tr>
					<tr>
						<td class="bold_td">LANGUAGE:</td>
						<td>  <?php echo e($user->languages); ?></td>
					</tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</section>
<!-- education part --><br />
&nbsp;
<h4 class="professionalskills_heading">Education</h4>
&nbsp; <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table class="workexperiencetable" id="education_table">
	<tbody class="workexperiencetable_body">
		<tr class="educationtable_tr">
			<td class="workexperiencetable_td1" width="40%">
			<p class="education_year"> <?php echo e($edu -> duration); ?></p>
			&nbsp;

			<p class="education_degree"><?php echo e($edu -> degree); ?></p>
			</td>
			<td class="workexperiencetable_td2" width="60%">
			<p class="education_course"><?php echo e($edu -> department); ?></p>

			<p class="education_college"><?php echo e($edu -> school); ?></p>
			</td>
		</tr>
	</tbody>
</table> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&nbsp;



</section>
</article>
</center>
</body>
</html>
<?php /**PATH C:\Users\kyath\test\resources\views/about.blade.php ENDPATH**/ ?>