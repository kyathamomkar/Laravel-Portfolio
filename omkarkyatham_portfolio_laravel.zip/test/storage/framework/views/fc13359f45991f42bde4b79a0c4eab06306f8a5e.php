<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
    <script src="JS/common.js"></script>
</head>
<body>
<header>
<nav>
<ul class="nav_list">
    <li><a href="" id="logintext">
            <?php if(Session::has('user')): ?>LOGOUT
            <?php else: ?> LOGIN <?php endif; ?></a></li>
	<li><a href="contact">CONTACT</a></li>
	<li><a href="prices">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a class="active_nav" href="experience">EXPERIENCE</a></li>
	<li><a href="portfolio">PORTFOLIO</a></li>
	<li><a href="skills">SKILLS</a></li>
	<li><a href="about">ABOUT</a></li>
	<li><a href="default">HOMEPAGE</a></li>
	<li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
</ul>

<select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>

    <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>
</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper">&nbsp;
<h4 class="professionalskills_heading">Work Experience</h4>
&nbsp;

<?php $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<table class="workexperiencetable">
	<tbody class="workexperiencetable_body">
		<tr class="workexperiencetable_tr">
			<td class="workexperiencetable_td1">
			<p class="workexperiencetable_company" style="text-align:center"><?php echo e($exp->duration); ?><br />
			<br />
                <?php echo e($exp->employer); ?></p>
			</td>
			<td class="workexperiencetable_td2">
			<p class="workexperiencetable_company_role_name"><?php echo e($exp->position); ?></p>

			<p class="workexperiencetable_company_role"><br />
                <?php echo e($exp->description); ?></p>
			</td>
		</tr>
	</tbody>
</table>
&nbsp;<br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>&nbsp;



</section>
</article>
</center>
</body>
</html>
<?php /**PATH C:\Users\kyath\test\resources\views/experience.blade.php ENDPATH**/ ?>