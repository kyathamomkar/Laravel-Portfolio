<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Aboutuser extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('aboutuser', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('age');
            $table->string('description');
            $table->integer('phone');
            $table->string('languages');
            $table->string('address');
            $table->string('email');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
		Schema::dropIfExists('aboutuser');
	 //
    }
}
