<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Portfolio Website</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/portfolio.css">
        <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
         <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="JS/temp_functions.js"></script>
        <script src="JS/common.js"></script>

        	<style>
.flex-container {
  display: flex;
  flex-wrap: wrap;

  justify-content: center;
  max-width: 1000px;
}

.flex-container > div  {


  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}
</style>
    </head>
    <body >
        <header>
            <nav>
                <ul class="nav_list">

                    <li><a href="" id="logintext">
                            @if(Session::has('user'))LOGOUT
                            @else LOGIN @endif</a></li>
                    <li><a href="contact">CONTACT</a></li>
                    <li><a href="prices">PRICES</a></li>
                    <li ><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
                    <li><a href="experience">EXPERIENCE</a></li>
                    <li><a href="portfolio" class="active_nav">PORTFOLIO</a></li>
                    <li><a href="skills">SKILLS</a></li>
                    <li><a href="about">ABOUT</a></li>
                    <li><a href="default">HOMEPAGE</a></li>
                    <li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
              </ul>
              <select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>
     <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>
            </nav>
        </header>
    <center>
        <article class="main_article">
            <section id="wrapper"> <br><br>
               <h3 class="portfolio_heading">Portfolio</h3> <br>
               <ul class="portfolio_icons">
                   <li id="icon1"><a id="projects_icon"><i class="fa fa-laptop" aria-hidden="true"></i></a></li>
                   <li id="icon2"><a id="gallery_icon"><i class="fa fa-picture-o" aria-hidden="true"></i></a></li>
                   <li id="icon3"><a id="photos_icon"><i class="fa fa-camera" aria-hidden="true"></i></a></li>
               </ul>
               <br><br>

               <div class="flex-container">
                   @foreach($projects as $project)
              <div>
               <table class="portfolio_images_table" id="projects">
                   <tr>

                       <td><a href="{{$project->link}}" target="_blank"><img src="{{ asset('storage/'.$project->imagepath) }}" class="imageview"/></a></td>
                   </tr>

               </table>

             </div>
                   @endforeach&nbsp;


               </div>
               <table class="portfolio_images_table" id="gallery" style="display: none">
                   <tr>
                       <td><a href="https://github.com/kyathamomkar/Aws_boto3_python" target="_blank"><img src="images/gallery/kerala.JPG" ></a></td>
                       <td><a href="https://github.com/kyathamomkar/terraform_examples" target="_blank"><img src="images/gallery/chick.JPG" ></a></td>
                   </tr>
                   <tr>
                       <td><a href="https://github.com/kyathamomkar/linux-tricks" target="_blank"><img src="images/gallery/nandi.JPG" ></a></td>
                       <td><a href="https://github.com/kyathamomkar/ansible" target="_blank"><img src="images/gallery/yashna.JPG" ></a></td>
                   </tr>
               </table>


                 <table class="portfolio_images_table" id="photos" style="display: none">
                   <tr>
                        <td><a href="https://github.com/kyathamomkar/Aws_boto3_python" target="_blank"><img src="images/gallery/kerala.JPG" ></a></td>
                       <td><a href="https://github.com/kyathamomkar/terraform_examples" target="_blank"><img src="images/gallery/chick.JPG" ></a></td>
                   </tr>
                   <tr>
                       <td><a href="https://github.com/kyathamomkar/linux-tricks" target="_blank"><img src="images/gallery/nandi.JPG" ></a></td>
                       <td><a href="https://github.com/kyathamomkar/ansible" target="_blank"><img src="images/gallery/yashna.JPG" ></a></td>
                   </tr>
               </table>

        </section>
        </article>
    </center>
    </body>
</html>
