<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Portfolio Website</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="CSS/portfolio.css">
        <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
        <script src="JS/common.js"></script>
    </head>
    <body class="contact_page" >
        <header>
            <nav>
                <ul class="nav_list">
                    <li><a href="" id="logintext">
                            @if(Session::has('user'))LOGOUT
                            @else LOGIN @endif</a></li>
                    <li><a href="contact" class="active_nav">CONTACT</a></li>
                    <li><a href="prices">PRICES</a></li>
                    <li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
                    <li><a href="experience">EXPERIENCE</a></li>
                    <li><a href="portfolio">PORTFOLIO</a></li>
                    <li><a href="skills">SKILLS</a></li>
                    <li><a href="about">ABOUT</a></li>
                    <li><a href="default">HOMEPAGE</a></li>
                    <li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
              </ul>

              <select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>
    <option value="about.php">ABOUT</option>
    <option value="skills.php">SKILLS</option>
    <option value="portfolio.php">PORTFOLIO</option>
    <option value="experience.php">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices.php">PRICES</option>
    <option value="contact.php">CONTACT</option>
  </select>
            </nav>
        </header>

         <center>
        <article class="main_article">
        <section id="wrapper">
            <section class="contact_form">

                <table class="contact_form_table">
                    <thead >
                    <caption>Contact Me</caption>
                </thead>
                <tbody>
                <th >Feel free to contact me </th>
                <th class="address_td"></th>
                <tr>
                    <td class="contact_form_column">
                        <form action="php/contactme.php" method="post"> <div class="input-icons">
                    <i class="fa fa-user-circle icon" ></i> <input type="text" placeholder="Name" name="name" class="inputfield" required> </input> <br><br><br>
                 <i class="fa fa-file-text icon" ></i>   <input type="text" placeholder="Subject" name="subject" class="inputfield" required> </input><br><br><br>
                 <i class="fa fa-envelope icon" ></i>   <input type="email" placeholder="Email" name="email" class="inputfield" required> </input><br><br><br>
                 <textarea placeholder="Message" class="inputfield" id="messagefield" rows="3" name="message" required></textarea><br><br>
                 <input type="submit" class="formsubmission_button">
                            </div>
                </form>

       </td>
                    @foreach ($details as $user)
                    <td class="address_td">
                        <p><strong>Address</strong><br> {{$user->address}}
                            <br><br>
                            <strong>Phone</strong><br>
                            {{$user->phone}}
                        <br><br>
                            <strong>Email</strong><br>
                            {{$user->email}}

                        </p>
                    </td>
                        @endforeach
                </tr>

                </tbody>

                </table>

            </section>
        </section>
        </article>
             <br><br><br><br>
             <footer class="footer_div">
        <a href="#" class="fa fa-facebook"></a> &nbsp;&nbsp;
        <a href="#" class="fa fa-twitter"></a>&nbsp;&nbsp;
        <a href="#" class="fa fa-google-plus"></a>&nbsp;&nbsp;
        <a href="#" class="fa fa-instagram"></a> <br><br>
        <p class="footer_text">
            <strong class="footer_name">Omkar Kyatham </strong><br><br>
            &copy; Omkar Kyatham. All rights reserved.

        </p>
    </footer>
    </center>




    </body>
</html>
