<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Portfolio Website</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="CSS/portfolio.css" rel="stylesheet" type="text/css" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="JS/temp_functions.js"></script>
    <meta name="csrf-token" content="{{ csrf_token() }}">




</head>
<body class="index_page">
<header>
<nav class="index_nav">
<ul class="nav_list">

    <li><button class="login_in_nav"><a >LOGIN</a> </button></li>
	<li><a href="contact">CONTACT</a></li>
	<li><a href="prices">PRICES</a></li>
	<li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
	<li><a href="experience">EXPERIENCE</a></li>
	<li><a href="portfolio">PORTFOLIO</a></li>
	<li><a href="skills">SKILLS</a></li>
	<li><a href="about">ABOUT</a></li>
	<li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
</ul>

<select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>

     <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>

</nav>
</header>

<center>
<article class="main_article">
<section id="wrapper"><br />
<br />
<br />
<br />
<br />
<br />
<img alt="Avatar" class="profilepic" src="images/profilepic.jpg" /><br />
&nbsp;
<p class="index_paragraph">OMKAR KYATHAM</p>

<p class="index_roles">WEB DEVELOPER, PROGRAMMER, PHOTOGRAPHER</p>

<p></p>
<div class="flex-container" ><table>
<tr> <td><div><button class="index_table_row_td">Hire Me</button></div></td> <td><div><button class="index_table_row_td2" id="myBtn">Download CV</button></div> </td>

</tr></table>
</div>


<!-- below is code for pop up window -->
<div class="overlay"></div>

<div class="main-popup">
<div class="popup-header">
<div id="popup-close-button"></div>

<ul>
	<li><p  id="sign-in">Login</p></li>
	<li><p  id="register">SignUp</p></li>
</ul>
</div>
<!--.popup-header-->

<div class="popup-content"> <br>
<div id="message"></div>
<form class="sign-in"><label for="email">User:</label> <input id="email" name="username" type="text" required/>
    <label for="password">Password:</label> <input id="password" name="password" type="password" required/> <!--  <p class="check-mark">
        <input type="checkbox" id="remember-me">
       <label for="remember-me">Remember me</label>
      </p> --> <input class="close" id="close" type="submit" value="Close" />
    <input class="getin" id="submit" name="submit" type="button" value="Get in" /></form>
<br />
<br />
<br />
<br />
<br />
&nbsp;
<form  class="register">
<label for="email-register">Username:</label> <input id="email-register" type="text" required/>
<label for="password-register">Password:</label> <input id="password-register" type="password" required/> <label for="password-confirmation">Confirm Password:</label> <input id="password-confirmation" type="password" required/>
<input id="submit" type="button" value="Create Account" class="registration"/></form>







</div>




<!--.popup-content--></div>
<!--.main-popup--> <!--  popup closed-->






</section>
</article>
<br />
<br />
<br />
<br />
&nbsp;
<footer class="footer_div"><a href="#" class="fa fa-facebook"></a> &nbsp;&nbsp;
        <a href="#" class="fa fa-twitter"></a>&nbsp;&nbsp;
        <a href="#" class="fa fa-google-plus"></a>&nbsp;&nbsp;
        <a href="#" class="fa fa-instagram"></a> <br><br>
<p class="footer_text">&copy; Omkar Kyatham. All rights reserved.</p>
</footer>
</center>


<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close2" id="close2">&times;</span>
    <h4>Download the CV</h4>
    <form method="post" action="http://omkarkyatham.uta.cloud/php/email.php">
        <input type="email" placeholder="Enter Email" required name="receiver"> <button id="emailbutton">Send via email</button></form> <br>
    <a href="http://omkarkyatham.uta.cloud/cv_omkar_kyatham.docx" download>
       <button id="emailbutton" >Download Now</button> </a>
  </div>

</div>

</body>









</html>
