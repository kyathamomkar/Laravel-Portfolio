<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Portfolio Website</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
        <link rel="stylesheet" type="text/css" href="CSS/portfolio.css">
        <script src="JS/common.js"></script>

    <style>
.flex-container {
  display: flex;
  flex-wrap: wrap;

  justify-content: center;
  max-width: 60%;
}

.flex-container > div {

  width: 250px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}

.prices_inner_table{

    text-align: center;
}
</style>



    </head>
    <body class="prices_page">
        <header>
            <nav>
                <ul class="nav_list">

                    <li><a href="" id="logintext">
                            @if(Session::has('user'))LOGOUT
                            @else LOGIN @endif</a></li>
                    <li><a href="contact">CONTACT</a></li>
                    <li><a href="prices" class="active_nav">PRICES</a></li>
                    <li><a href="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</a></li>
                    <li><a href="experience">EXPERIENCE</a></li>
                    <li><a href="portfolio">PORTFOLIO</a></li>
                    <li><a href="skills">SKILLS</a></li>
                    <li><a href="about">ABOUT</a></li>
                    <li><a href="default">HOMEPAGE</a></li>
                    <li class="name_nav"><a href="default">OMKAR KYATHAM</a></li>
              </ul>

              <select onChange="window.location.href=this.value" class="select-css">
    <option value="" selected="selected">Select</option>

    <option value="about">ABOUT</option>
    <option value="skills">SKILLS</option>
    <option value="portfolio">PORTFOLIO</option>
    <option value="experience">EXPERIENCE</option>
    <option value="http://blog.omkarkyatham.uta.cloud/blog/">BLOG</option>
    <option value="prices">PRICES</option>
    <option value="contact">CONTACT</option>
  </select>
            </nav>
        </header>
    <center> <br>
 <h4 class="professionalskills_heading">Prices</h4> <br><br>
<div class="flex-container">
    <?php
$counter= 0;?>
@foreach( $prices as $price)

          <?php

            $counter++;
            if($counter==4)
                $counter=1;
            ?>


  <div class="prices_outer_table_td"><table class="prices_inner_table" >
                             <tr height="25%"><td class="cart_td<?php echo $counter; ?>"><p><i class="fa fa-shopping-cart" id="cart1" ></i></p></td></tr>
                                <tr><td class="workrate"><div class="bigtext"> ${{$price->pay}} </div>   {{$price->position}}</td></tr>




          <tr height="8%" id="bottomrows" class="work_tasks"><td>{{$price->skills}}</td></tr>



                                <tr height="8%" class="contact_tr" id="bottomrows"><td><a href="contact" class="contactus_href">Contact Us</a></td></tr>
                            </table>

  </div>
@endforeach
</div>

</center>
    </body>
</html>
